const { urlencoded, json } = require('express');
const express = require('express');
const mongoose = require('mongoose');
const app = express();
require('./intdn')()
app.use(urlencoded({extended:false}))
app.use(json())

const apiRouter = require('./routers/todorouter')
app.use('/api',apiRouter)

app.listen(8080,console.log("Server is running........"))