const Todo = require("../model/todomodel")

exports.getAllTodo = async (req, res, next) => {
    try {
        let date = new Date()
        date.setFullYear(date.getFullYear() - 20)
        const result = await Todo.find({
            DOB:{
                $lt:date
            }
        })
        res.send({
            Status: 'SUCCESSFULL',
            Message: 'successfully all Todo information',
            Data: result
        })
    } catch (error) {
        res.send(error.message)
    }
}

exports.createTodo = async (req, res, next) => {
    try {
        const rest = new Todo(req.body)
        const result = await rest.save()
        res.send({
            Status: 'SUCCESSFULL',
            Message: 'successfully added Todo',
            Data: 1
        })
    } catch (error) {
        console.log("Error", error)
    }
}