const express = require('express');
const { createTodo, getAllTodo } = require('../controller/todocontroller');
const router = express.Router();

router.get('/todo',getAllTodo)
router.post('/todo',createTodo)

module.exports = router