const mongoose = require('mongoose')

module.exports = () => {
    mongoose.connect('mongodb://localhost/todo_list',
        {
            useNewUrlParser: true,
        }).then(() => {
            console.log("Mongodb connected....")
        }).catch(error => {
            console.log(error.message)
        })
    mongoose.connection.on('connected', () => {
        console.log("Mongoose connected to db.......")
    })
}